enum Retning {              //en retning klasse
    NORD, SØR, ØST, VEST;
}
